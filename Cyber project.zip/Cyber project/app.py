
import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

st.title("🔐 Cybersecurity Log Analyzer")

uploaded_file = st.file_uploader("Upload Log File")

if uploaded_file:
    st.write("File uploaded successfully ✅")

    data = uploaded_file.read().decode("utf-8").split("\n")

    logs = []
    for line in data:
        if line:
            parts = line.split(" - ")
            if len(parts) == 2:
                logs.append({
                    "IP": parts[0].strip(),        # ✅ FIXED
                    "Status": parts[1].strip()     # ✅ FIXED
                })

    df = pd.DataFrame(logs)

    original_df = df.copy()

    # Filter
    st.sidebar.header("Filters")
    status_filter = st.sidebar.selectbox(
        "Select Status", ["All", "login success", "login failed"]
    )

    if status_filter != "All":
        df = df[df["Status"] == status_filter]

    st.subheader("📄 Log Data")
    st.write(df)

    # Analysis
    failed = original_df[original_df["Status"] == "login failed"]
    count = failed["IP"].value_counts()

    # 🚨 Alerts
    st.subheader("🚨 Suspicious Activity")
    found = False
    for ip, num in count.items():
        if num >= 3:
            st.error(f"🚨 {ip} has {num} failed login attempts!")
            found = True

    if not found:
        st.success("No major threats detected ✅")

    # 📊 Graph
    st.subheader("📊 Failed Login Attempts")
    if not count.empty:
        fig, ax = plt.subplots()
        ax.bar(count.index, count.values)
        ax.set_xlabel("IP Address")
        ax.set_ylabel("Attempts")
        ax.set_title("Failed Logins per IP")
        st.pyplot(fig)

    # 🌍 Location
    st.subheader("🌍 IP Location")
    fake_locations = {
        "192.168.1.1": "India",
        "192.168.1.2": "USA",
        "192.168.1.3": "America",
        "10.0.0.1": "Russia"
    }

    for ip in count.index:
        location = fake_locations.get(ip, "Unknown")
        st.write(f"🌐 {ip} → {location}")